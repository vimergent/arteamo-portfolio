// Mobile Menu Toggle
const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const navMenu = document.querySelector('.nav-menu');

mobileMenuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    mobileMenuToggle.classList.toggle('active');
});

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Active Navigation Link
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');

function setActiveNav() {
    let scrollY = window.pageYOffset;
    
    sections.forEach(section => {
        const sectionHeight = section.offsetHeight;
        const sectionTop = section.offsetTop - 100;
        const sectionId = section.getAttribute('id');
        
        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });
        }
    });
}

window.addEventListener('scroll', setActiveNav);

// Project Filtering
const filterButtons = document.querySelectorAll('.filter-btn');
const projectCards = document.querySelectorAll('.project-card');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Update active button
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        const filter = button.getAttribute('data-filter');
        
        projectCards.forEach(card => {
            if (filter === 'all' || card.getAttribute('data-category') === filter) {
                card.style.display = 'block';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 10);
            } else {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
    });
});

// Sorting
const sortSelect = document.getElementById('sort-select');
const projectsGrid = document.querySelector('.projects-grid');

sortSelect.addEventListener('change', () => {
    const sortValue = sortSelect.value;
    const projects = Array.from(projectCards);
    
    projects.sort((a, b) => {
        if (sortValue === 'newest') {
            return parseInt(b.getAttribute('data-year')) - parseInt(a.getAttribute('data-year'));
        } else if (sortValue === 'oldest') {
            return parseInt(a.getAttribute('data-year')) - parseInt(b.getAttribute('data-year'));
        } else if (sortValue === 'name') {
            const nameA = a.querySelector('h3').textContent.toLowerCase();
            const nameB = b.querySelector('h3').textContent.toLowerCase();
            return nameA.localeCompare(nameB);
        }
    });
    
    projects.forEach(project => {
        projectsGrid.appendChild(project);
    });
});

// Parallax Effect on Hero
const hero = document.querySelector('.hero');

window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const parallax = scrolled * 0.5;
    hero.style.transform = `translateY(${parallax}px)`;
});

// Lazy Loading Images
const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src || img.src;
            img.classList.add('loaded');
            observer.unobserve(img);
        }
    });
});

document.querySelectorAll('.project-image img').forEach(img => {
    imageObserver.observe(img);
});

// Project Card Click Handler
projectCards.forEach(card => {
    card.addEventListener('click', function() {
        const projectTitle = this.querySelector('h3').textContent;
        const projectMeta = this.querySelector('.project-meta').textContent;
        const projectDesc = this.querySelector('.project-desc').textContent;
        const projectImage = this.querySelector('img').src;
        
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'project-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <div class="modal-image">
                    <img src="${projectImage}" alt="${projectTitle}">
                </div>
                <div class="modal-info">
                    <h2>${projectTitle}</h2>
                    <p class="modal-meta">${projectMeta}</p>
                    <p class="modal-desc">${projectDesc}</p>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        document.body.style.overflow = 'hidden';
        
        // Close modal
        modal.querySelector('.close-modal').addEventListener('click', () => {
            modal.remove();
            document.body.style.overflow = 'auto';
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
                document.body.style.overflow = 'auto';
            }
        });
    });
});

// Add modal styles dynamically
const modalStyles = `
    .project-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 2000;
        animation: fadeIn 0.3s ease;
    }
    
    .modal-content {
        background: white;
        max-width: 1200px;
        width: 90%;
        max-height: 90vh;
        overflow-y: auto;
        position: relative;
        animation: slideIn 0.3s ease;
    }
    
    .close-modal {
        position: absolute;
        top: 20px;
        right: 30px;
        font-size: 2rem;
        cursor: pointer;
        z-index: 10;
        color: #333;
    }
    
    .modal-image {
        width: 100%;
        height: 60vh;
        overflow: hidden;
    }
    
    .modal-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .modal-info {
        padding: 3rem;
    }
    
    .modal-meta {
        font-size: 1rem;
        color: #666;
        margin: 1rem 0;
    }
    
    .modal-desc {
        font-size: 1.125rem;
        line-height: 1.8;
        color: #333;
    }
    
    @keyframes slideIn {
        from {
            transform: translateY(50px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    
    @media (max-width: 768px) {
        .modal-content {
            width: 100%;
            height: 100%;
            max-height: 100vh;
        }
        
        .modal-info {
            padding: 2rem;
        }
    }
`;

const styleSheet = document.createElement('style');
styleSheet.textContent = modalStyles;
document.head.appendChild(styleSheet);